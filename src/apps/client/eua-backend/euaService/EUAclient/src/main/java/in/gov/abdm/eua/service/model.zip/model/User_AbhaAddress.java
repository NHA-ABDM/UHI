package in.gov.abdm.eua.client.model;

import javax.persistence.*;
@Entity
@Table(schema = "eua")
public class User_AbhaAddress {
    @Column(name = "user_abha_address_id")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String userAbhaAddressId;
    @Column(name = "abha_address")
    private String abhaAddress;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName ="user_id")
    private User user;


}
