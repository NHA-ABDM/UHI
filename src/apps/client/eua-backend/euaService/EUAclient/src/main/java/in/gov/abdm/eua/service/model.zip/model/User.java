package in.gov.abdm.eua.client.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(schema = "eua")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "user_id")
    private String userId;
    @Column(name = "first_name", nullable = false)
    private String firstName;
    @Column(name = "middle_name")
    private String middleName;
    @Column(name = "last_name")
    private String lastName;
    @Column(name = "abha_id")
    private String abhaId;
    @Column(name = "email")
    private String email;
    @Column(name = "password", nullable = false)
    private String password;
    @Column(name = "mobile")
    private String mobile;

    @OneToMany(mappedBy = "user")
    private Set<Orders> orders;

    @OneToMany(mappedBy = "user")
    private Set<Payments> payments;

    @OneToMany(mappedBy = "user")
    private Set<UserRefreshToken> userRefreshTokens;

    @OneToMany(mappedBy = "user")
    private Set<User_AbhaAddress> user_abhaAddresses;

    @OneToMany(mappedBy = "user")
    private Set<Address> addresses;

    @OneToMany(mappedBy = "user")
    private Set<UserDevice> userDevices;

    @OneToMany(mappedBy = "user")
    private Set<Message> messages;

}
